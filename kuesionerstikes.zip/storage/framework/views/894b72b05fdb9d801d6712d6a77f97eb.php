<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kuesioner Kepuasan</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>

<body class="bg-gray-100">
    <?php if (isset($component)) { $__componentOriginal4619374cef299e94fd7263111d0abc69 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal4619374cef299e94fd7263111d0abc69 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.app-layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
        <div class="max-w-4xl mx-auto bg-white p-8 mt-10 rounded-lg shadow-lg">
            <h2 class="text-3xl font-bold text-center mb-6">Kuesioner Kepuasan</h2>
            <p class="text-center text-gray-600 mb-6">Silakan isi kuesioner berikut sesuai dengan pengalaman.</p>
            
            <form action="<?php echo e(route('kuesioner3.store')); ?>" method="POST" class="space-y-6">
                <?php echo csrf_field(); ?>
                
                <div>
                    <label for="username" class="block text-lg font-semibold mb-2">Nama :</label>
                    <input required type="text" id="username" name="username" placeholder="Masukkan Nama"
                        class="w-full p-3 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500">
                </div>

                <div>
                    <label for="prodi" class="block text-lg font-semibold mb-2">Prodi :</label>
                    <input required type="text" id="prodi" name="prodi" placeholder="Masukkan Prodi"
                        class="w-full p-3 border rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500">
                </div>
                
                <hr>
                
                <?php $__currentLoopData = range(1, 15); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div>
                    <p class="text-lg font-semibold"><?php echo e($index); ?>. <?php echo e($questions[$index - 1]); ?></p>
                    <div class="grid grid-cols-2 sm:grid-cols-4 gap-4 mt-2">
                        <?php $__currentLoopData = [1 => 'Sangat Tidak Setuju', 2 => 'Tidak Setuju', 3 => 'Setuju', 4 => 'Sangat Setuju']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <label class="flex items-center gap-2">
                            <input required type="radio" name="q<?php echo e($index); ?>" value="<?php echo e($value); ?>" class="form-radio text-blue-500">
                            <?php echo e($label); ?>

                        </label>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <hr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
                <div class="mt-6 flex justify-between">
                    <a href="<?php echo e(route('dashboard')); ?>"
                        class="px-4 py-2 bg-blue-600 text-white rounded-lg font-semibold transition hover:bg-blue-700 text-center">
                        Kembali
                    </a>
                    <button type="submit" class="px-4 py-2 bg-green-500 text-white rounded-md font-semibold transition hover:bg-green-600">
                        Selesai
                    </button>
                </div>
            </form>
        </div>
     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal4619374cef299e94fd7263111d0abc69)): ?>
<?php $attributes = $__attributesOriginal4619374cef299e94fd7263111d0abc69; ?>
<?php unset($__attributesOriginal4619374cef299e94fd7263111d0abc69); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal4619374cef299e94fd7263111d0abc69)): ?>
<?php $component = $__componentOriginal4619374cef299e94fd7263111d0abc69; ?>
<?php unset($__componentOriginal4619374cef299e94fd7263111d0abc69); ?>
<?php endif; ?>
</body>
</html>
<?php /**PATH E:\laragon\www\kuesionerstikes\resources\views/kuesioner3/create.blade.php ENDPATH**/ ?>