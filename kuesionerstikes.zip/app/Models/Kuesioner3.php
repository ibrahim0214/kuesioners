<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Kuesioner3 extends Model
{
    protected $table = 'kuesioner3s';
    protected $primaryKey = 'id_kuesioner';
    protected $guarded = [];
}
