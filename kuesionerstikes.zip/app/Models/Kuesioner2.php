<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Kuesioner2 extends Model
{
    protected $table = 'kuesioner2s';
    protected $primaryKey = 'id_kuesioner';
    protected $guarded = [];
}
